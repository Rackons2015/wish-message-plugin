<?php
/*
Plugin Name: Wish Message
Plugin URI: http://www.rackons.com
Description: Display Wish Message with User Name (If registered on site), otherwise Guest on Site according to Time Zone i.e Good Morning, Username!.  Use only this Short code "<?php osc_run_hook('wishing_message', 'wish_messages'); ?> wherever you want. i.e header.php
Version: 1.1.2
Author: Rackons
Author URI: http://rackons.com
Author Email: info@rackons.com
Short Name: wish-message
*/
		

function wish_messages()
	{
		?>
	<style type="text/css">

.wish{ 
    Font-size:18px;                //you can change font size according to your website requirement
    font-family:Abyssinica SIL;    //you can change font family according to your website requirement
}
</style>

       
		 <!-- WISH MESSAGE START -->
<?php if( osc_users_enabled() ) { ?>
        <?php if( osc_is_web_user_logged_in() ) { ?>
<p class="wish"><span id="wish-message" ></span>Good<span id="wish-messages"></span><span><?php echo sprintf(__(' %s', 'wish_message'), osc_logged_user_name() . '!'); ?></span></p>
<?php } else { ?>

<p class="wish"><span id="wish-message" ></span>Good<span id="wish-messages"></span><span><?php echo sprintf(__(' Guest!', 'wish_message'), osc_logged_user_name() . '!'); ?></span></p>
<?php } ?>
<?php } ?>

<script>
if (new Date().getHours() < 12) {
    document.getElementById("wish-message").innerHTML = '<img src="<?php echo osc_plugin_url(__FILE__);?>images/morning.png" height="35" width="35">';
}
else if (new Date().getHours() < 16) {
    document.getElementById("wish-message").innerHTML = '<img src="<?php echo osc_plugin_url(__FILE__);?>images/noon.png"  height="35" width="35">';
}
else {
    document.getElementById("wish-message").innerHTML = '<img src="<?php echo osc_plugin_url(__FILE__);?>images/evening.png" height="35" width="35">';
}
</script>
<script>
if (new Date().getHours() < 12) {
    document.getElementById("wish-messages").innerHTML = " Morning,";
}
else if (new Date().getHours() < 16) {
    document.getElementById("wish-messages").innerHTML = " Afternoon,";
}
else {
    document.getElementById("wish-messages").innerHTML = " Evening,";
}
</script>

                       <!-- WISH MESSAGE END -->
		<?php 
	}
	

function wish_message_menu() {
    echo '<h3><a href="#">Wish Messages</a></h3>
    <ul>
        <li><a href="'.osc_admin_render_plugin_url("wish_message/admin/help.php").'?section=types">&raquo; ' . __('Help', 'wish_messages') . '</a></li>
    </ul>';
    }

osc_add_hook('wishing_message', 'wish_messages',10);
osc_add_hook('admin_menu', 'wish_message_menu');
